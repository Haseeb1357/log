<?php
$servername="localhost";
$username="root";
$password="";
$dbname="login";
$connection=mysqli_connect($servername,$username,$password,$dbname);
if($connection)
{
    echo "Connection Successfull";
}
else{
    echo "Error!";
}
$name=$_POST['name'];
$user_name=$_POST['uname'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$gender=$_POST['gender'];
$pwd=$_POST['pwd'];

$data="INSERT INTO tbl_reg(FUll_Name,User_Name,Email,Phone,Gender,Password)
 Values ('$name','$user_name','$email','$phone','$gender','$pwd')";
mysqli_query($connection,$data);
header('location:signup.php');
mysqli_close($connection);
?>